import React, { useState } from 'react';
import { IntroSplash } from './components/IntroSplash';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Framework } from './components/Framework';
import { Services } from './components/Services';
import { AuditForm } from './components/AuditForm';
import { Footer } from './components/Footer';

export const App: React.FC = () => {
  const [showIntro, setShowIntro] = useState(true);

  return (
    <>
      {showIntro && <IntroSplash onEnter={() => setShowIntro(false)} />}
      <div className={`min-h-screen flex flex-col bg-[#05070E] text-slate-100 transition-opacity duration-700 ${showIntro ? 'opacity-0 h-0 overflow-hidden' : 'opacity-100'}`}>
        <Navbar />
        <main className="flex-grow">
          <Hero />
          <Framework />
          <Services />
          <AuditForm />
        </main>
        <Footer />
      </div>
    </>
  );
};
